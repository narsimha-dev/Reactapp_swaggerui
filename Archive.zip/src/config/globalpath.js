const globalPath={

 USER_PATH:"https://narsimha.herokuapp.com",

}
export default globalPath;
