// import postApiCall from '../../services/postApiCall';
// export function loadPosts(){
//     return function(dispatch){
//         return postApiCall().getPosts(this.success,this.failure);
//     }
// }
//      function success(data){
//         dispatch(loadPostSuccess(data))
//     }
//     function failure(error)
//     {
//         throw(error)
//     }
