import React, { Component } from 'react';
class Commnets extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <p>Commnets</p>
         );
    }
}
 
export default Commnets;